/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author mario.sanper.2
 */
public class Control {
    private ArrayList <Farola> farolas = new ArrayList<>();
    private Random random = new Random();
    private final int numFarolas = 5;
    private Zona zona;
    
    public void init(){
        rellenarFarolas();
        mostrarFarolas();
    }
    
    private void rellenarFarolas(){
        for (int i = 0; i < numFarolas; i++) {
            farolas.add(new Farola("F"+ i,generarConsumo(),generarZona()));
        }
    }
    private Zona generarZona(){
        int num = random.nextInt(0, 4);
        return Zona.values()[num];
    }
    private double generarConsumo(){
        return random.nextDouble(7.0,76.0);
    }
    private void mostrarFarolas(){
        for (Farola farola : farolas) {
            System.out.println("");
            System.out.println("==================================");
            System.out.println("Codigo: " + farola.getCodigo());
            System.out.printf("Consumo: %2fn " ,farola.getConsumo());
            System.out.println("Zona: " + farola.getZona());
            System.out.println("==================================");
            
        }
    }
}
